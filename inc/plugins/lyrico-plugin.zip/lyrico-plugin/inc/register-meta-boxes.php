<?php
/**
 * Register Custom meta boxes
 *
 * @package lyrico-plugin
 * @since 1.0.0
 */

/**
 * Add meta boxes for custom post types
 */
function lyrico_add_custom_box() {

	add_meta_box(
		'lyrics-meta-boxes',
		esc_html__( 'About Lyrics', 'lyrico-plugin' ),
		'lyrico_custom_box_html_lyrics',
		'lyrico_lyrics',
		'normal',
		'default'
	);
	add_meta_box(
		'album-meta-boxes',
		esc_html__( 'About Album', 'lyrico-plugin' ),
		'lyrico_custom_box_html_album',
		'lyrico_album',
		'normal',
		'default'
	);
	add_meta_box(
		'artist-meta-boxes',
		esc_html__( 'About Artist', 'lyrico-plugin' ),
		'lyrico_custom_box_html_artist',
		'lyrico_artist',
		'normal',
		'default'
	);
}
add_action( 'add_meta_boxes', 'lyrico_add_custom_box' );

/**
 * Create custom meta boxes inputs for lyrics.
 *
 * @param object $post the post.
 */
function lyrico_custom_box_html_lyrics( $post ) {
	$the_post_id = $post->ID;
	wp_nonce_field( basename( __FILE__ ), 'lyrico_nonce_field' );

	/* Get all artists and put into array */
	$all_artists = array();

	$query = new WP_Query(
		array(
			'post_type'      => 'lyrico_artist',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
			'orderby'        => 'post_date',
			'order'          => 'DESC',
		)
	);

	if ( $query->have_posts() ) :
		while ( $query->have_posts() ) :
			$query->the_post();

			if ( ! empty( get_the_title() ) ) {
				$all_artists[ get_the_id() ] = get_the_title();
			}

		endwhile;
		wp_reset_postdata();
	endif;

	/* Get all albums and put into array */
	$all_albums = array();

	$query = new WP_Query(
		array(
			'post_type'      => 'lyrico_album',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
			'orderby'        => 'post_date',
			'order'          => 'DESC',
		)
	);

	if ( $query->have_posts() ) :
		while ( $query->have_posts() ) :
			$query->the_post();

			if ( ! empty( get_the_title() ) ) {
				$all_albums[ get_the_id() ] = get_the_title();
			}

		endwhile;
		wp_reset_postdata();
	endif;
	?>

	<div id="lyrico-tabs">
		<ul class="tab">
			<li><a href="#lyrics-tab-1"><span class="dashicons dashicons-format-gallery"></span><span> <?php esc_html_e( 'Artists &#x26; Album', 'lyrico-plugin' ); ?></span></a></li>
			<li><a href="#lyrics-tab-2"><span class="dashicons dashicons-editor-aligncenter"></span><span> <?php esc_html_e( 'Details', 'lyrico-plugin' ); ?></span></a></li>
			<li><a href="#lyrics-tab-3"><span class="dashicons dashicons-external"></span><span> <?php esc_html_e( 'Links', 'lyrico-plugin' ); ?></span></a></li>
		</ul>

		<div id="lyrics-tab-1" class="tabcontent">
			<span class="content-header"><?php esc_html_e( 'Select Artist and Album', 'lyrico-plugin' ); ?></span>
			<table class="form-table">
				<?php
					lyrico_create_box(
						array(
							'id'      => 'lyrico_artist',
							'title'   => esc_html__( 'Primary Artist:', 'lyrico-plugin' ),
							'type'    => 'primary_artist_select',
							'options' => $all_artists,
						),
						$the_post_id
					);

					lyrico_create_box(
						array(
							'id'      => 'lyrico_other_artists',
							'title'   => esc_html__( 'Other Artists:', 'lyrico-plugin' ),
							'type'    => 'other_artists_select',
							'options' => $all_artists,
						),
						$the_post_id
					);

					lyrico_create_box(
						array(
							'id'      => 'lyrico_album',
							'title'   => esc_html__( 'Album:', 'lyrico-plugin' ),
							'type'    => 'album_select',
							'options' => $all_albums,
						),
						$the_post_id
					);

					lyrico_create_box(
						array(
							'id'    => 'lyrico_order_in_album',
							'desc'  => 'Order of the song in the album.',
							'title' => esc_html__( 'Album Order:', 'lyrico-plugin' ),
							'type'  => 'number',
						),
						$the_post_id
					);
				?>
			</table>

			<span style="color:#6c757d;">
				<br />
				<?php esc_html_e( '* Don&#x27;t Forget to create Album/Artist before creating Lyrics.', 'lyrico-plugin' ); ?>
			</span>
		</div>

		<div id="lyrics-tab-2" class="tabcontent">
			<span class="content-header"><?php esc_html_e( 'Details', 'lyrico-plugin' ); ?></span>

			<table class="form-table">
				<?php
					lyrico_create_box(
						array(
							'id'    => 'lyrico_song_writers',
							'desc'  => 'Lyricist(s) who wrote this lyrics. Write the producer and press &#x22;Enter&#x22; to add.',
							'title' => esc_html__( 'Song Writer(s):', 'lyrico-plugin' ),
							'type'  => 'dynamic_multiple_select',
						),
						$the_post_id
					);

					lyrico_create_box(
						array(
							'id'    => 'lyrico_producers',
							'desc'  => 'Person(s) who produced this recording(song). Write the producer and press &#x22;Enter&#x22; to add.',
							'title' => esc_html__( 'Producer(s):', 'lyrico-plugin' ),
							'type'  => 'dynamic_multiple_select',
						),
						$the_post_id
					);

					lyrico_create_box(
						array(
							'id'          => 'lyrico_length',
							'desc'        => 'Duration of the song. Seperate minute and second with colon (":").',
							'placeholder' => 'e.g. 4:05',
							'title'       => esc_html__( 'Length:', 'lyrico-plugin' ),
							'type'        => 'text',
						),
						$the_post_id
					);

					lyrico_create_box(
						array(
							'id'    => 'lyrico_released_year',
							'desc'  => 'if left blank or zero, it will show the released year from the album to which the lyrics belong.',
							'title' => esc_html__( 'Released Year:', 'lyrico-plugin' ),
							'type'  => 'number',
						),
						$the_post_id
					);
				?>
			</table>

			<span style="color:#6c757d;">
				<br />
				<?php esc_html_e( '* Don&#x27;t Forget to create Album/Artist before creating Lyrics.', 'lyrico-plugin' ); ?>
			</span>
		</div>

		<div id="lyrics-tab-3" class="tabcontent">
			<span class="content-header"><?php esc_html_e( 'Song Links', 'lyrico-plugin' ); ?></span>

			<table class="form-table">
				<?php
					lyrico_create_box(
						array(
							'id'    => 'lyrico_youtube_link',
							'title' => esc_html__( 'Youtube Link:', 'lyrico-plugin' ),
							'type'  => 'text',
						),
						$the_post_id
					);
				?>
				<?php
					lyrico_create_box(
						array(
							'id'    => 'lyrico_spotify_link',
							'title' => esc_html__( 'Spotify Link:', 'lyrico-plugin' ),
							'desc'  => 'To get Spotify song link, go Spotify App right click the Song > Share > Copy Song Link.',
							'type'  => 'text',
						),
						$the_post_id
					);
				?>
				<?php
					lyrico_create_box(
						array(
							'id'    => 'lyrico_spotify_app_link',
							'title' => esc_html__( 'Spotify App Uri:', 'lyrico-plugin' ),
							'desc'  => 'In Spotify App right click the Song > Share > Copy Spotify URI (e.g. spotify:track:7pKfPomDEeI4TPT6EOYjn9)',
							'type'  => 'text',
						),
						$the_post_id
					);
				?>
				<?php
					lyrico_create_box(
						array(
							'id'    => 'lyrico_soundcloud_link',
							'title' => esc_html__( 'Soundcloud Link:', 'lyrico-plugin' ),
							'type'  => 'text',
						),
						$the_post_id
					);
				?>
			</table>

			<span style="color:#6c757d;">
				<br />
				<?php esc_html_e( '* Don&#x27;t Forget to create Album/Artist before creating Lyrics.', 'lyrico-plugin' ); ?>
			</span>
		</div>
	</div> <!-- #lyrico-tabs -->
	<?php

}

/**
 * Create custom meta boxes inputs for albums.
 *
 * @param object $post the post id.
 */
function lyrico_custom_box_html_album( $post ) {

	$the_post_id = $post->ID;
	wp_nonce_field( basename( __FILE__ ), 'lyrico_nonce_field' );

	$all_artists = array();

	$query = new WP_Query(
		array(
			'post_type'      => 'lyrico_artist',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
			'orderby'        => 'post_date',
			'order'          => 'DESC',
		)
	);

	if ( $query->have_posts() ) :
		while ( $query->have_posts() ) :
			$query->the_post();

			if ( ! empty( get_the_title() ) ) {
				$all_artists[ get_the_id() ] = get_the_title();
			}

		endwhile;
		wp_reset_postdata();
	endif;
	?>

		<div id="about-album">
			<table class="form-table">
				<?php
				lyrico_create_box(
					array(
						'id'      => 'lyrico_artist',
						'title'   => esc_html__( 'Primary Artist:', 'lyrico-plugin' ),
						'type'    => 'primary_artist_select',
						'options' => $all_artists,
					),
					$the_post_id
				);
				?>
				<?php
					lyrico_create_box(
						array(
							'id'    => 'lyrico_released_year',
							'title' => esc_html__( 'Released Year:', 'lyrico-plugin' ),
							'type'  => 'number',
						),
						$the_post_id
					);
				?>
			</table>
		</div>
	<?php
}

/**
 * Create custom meta boxes inputs for artists.
 *
 * @param object $post the post.
 */
function lyrico_custom_box_html_artist( $post ) {
	$the_post_id = $post->ID;
	wp_nonce_field( basename( __FILE__ ), 'lyrico_nonce_field' );
	?>
	<div id="about-artist-div" class="clearfix">
		<table class="form-table">
		<?php
		lyrico_create_box(
			array(
				'id'    => 'lyrico_founding_year',
				'title' => esc_html__( 'Founding Year:', 'lyrico-plugin' ),
				'type'  => 'number',
			),
			$the_post_id
		);

		lyrico_create_box(
			array(
				'id'    => 'lyrico_dissolution_year',
				'title' => esc_html__( 'Dissolution Year:', 'lyrico-plugin' ),
				'type'  => 'number',
			),
			$the_post_id
		);

		lyrico_create_box(
			array(
				'id'    => 'lyrico_founding_location',
				'title' => esc_html__( 'Founding Location:', 'lyrico-plugin' ),
				'type'  => 'text',
			),
			$the_post_id
		);

		lyrico_create_box(
			array(
				'id'    => 'lyrico_related_website',
				'title' => esc_html__( 'Website:', 'lyrico-plugin' ),
				'type'  => 'text',
			),
			$the_post_id
		);
		?>
		</table>
	</div>
	<?php
}

/**
 * Save the meta box's post metadata.
 *
 * @param object $post_id the post id.
 */
function lyrico_save_postdata( $post_id ) {
	$the_post_type = get_post_type( $post_id );

	if ( ! isset( $_POST['lyrico_nonce_field'] ) || ! wp_verify_nonce( $_POST['lyrico_nonce_field'], basename( __FILE__ ) ) ) {
		return $post_id;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return $post_id;
	}

	if ( 'lyrico_lyrics' === $the_post_type ) {
		$meta_keys_select_multiple = array(
			'lyrico_song_writers',
			'lyrico_producers',
			'lyrico_other_artists',
		);

		$meta_keys_select = array(
			'lyrico_artist',
			'lyrico_album',
		);

		$meta_keys_string = array(
			'lyrico_length',
			'lyrico_spotify_app_link',
		);

		$meta_keys_url = array(
			'lyrico_youtube_link',
			'lyrico_spotify_link',
			'lyrico_soundcloud_link',
		);

		$meta_keys_integer = array(
			'lyrico_order_in_album',
			'lyrico_released_year',
		);
		foreach ( $meta_keys_select_multiple as $meta_key ) :
			$old_meta = get_post_meta( $post_id, $meta_key, true );
			if ( array_key_exists( $meta_key, $_POST ) ) {
				update_post_meta( $post_id, $meta_key, array_map( 'sanitize_text_field', wp_unslash( $_POST[ $meta_key ] ) ) );
			} elseif ( ! isset( $_POST[ $meta_key ] ) && isset( $old_meta ) ) {
				delete_post_meta( $post_id, $meta_key );
			}
		endforeach;

		foreach ( $meta_keys_select as $meta_key ) :
			$old_meta = get_post_meta( $post_id, $meta_key, true );
			if ( array_key_exists( $meta_key, $_POST ) ) {
				update_post_meta( $post_id, $meta_key, sanitize_text_field( wp_unslash( $_POST[ $meta_key ] ) ) );
			} elseif ( ! isset( $_POST[ $meta_key ] ) && isset( $old_meta ) ) {
				delete_post_meta( $post_id, $meta_key );
			}
		endforeach;

		foreach ( $meta_keys_string as $meta_key ) :
			if ( isset( $_POST[ $meta_key ] ) ) {
				update_post_meta( $post_id, $meta_key, sanitize_text_field( wp_unslash( $_POST[ $meta_key ] ) ) );
			}
		endforeach;

		foreach ( $meta_keys_url as $meta_key ) :
			if ( isset( $_POST[ $meta_key ] ) ) {
				update_post_meta( $post_id, $meta_key, esc_url_raw( wp_unslash( $_POST[ $meta_key ] ) ) );
			}
		endforeach;

		foreach ( $meta_keys_integer as $meta_key ) :
			if ( isset( $_POST[ $meta_key ] ) ) {
				update_post_meta( $post_id, $meta_key, intval( wp_unslash( $_POST[ $meta_key ] ) ) );
			}
		endforeach;
	}

	if ( 'lyrico_artist' === $the_post_type ) {

		$meta_keys_string = array(
			'lyrico_founding_location',
		);

		$meta_keys_url = array(
			'lyrico_related_website',
		);

		$meta_keys_integer = array(
			'lyrico_founding_year',
			'lyrico_dissolution_year',
		);

		foreach ( $meta_keys_string as $meta_key ) :
			if ( isset( $_POST[ $meta_key ] ) ) {
				update_post_meta( $post_id, $meta_key, sanitize_text_field( wp_unslash( $_POST[ $meta_key ] ) ) );
			}
		endforeach;

		foreach ( $meta_keys_url as $meta_key ) :
			if ( isset( $_POST[ $meta_key ] ) ) {
				update_post_meta( $post_id, $meta_key, esc_url_raw( wp_unslash( $_POST[ $meta_key ] ) ) );
			}
		endforeach;

		foreach ( $meta_keys_integer as $meta_key ) :
			if ( isset( $_POST[ $meta_key ] ) ) {
				update_post_meta( $post_id, $meta_key, intval( wp_unslash( $_POST[ $meta_key ] ) ) );
			}
		endforeach;
	}

	if ( 'lyrico_album' === $the_post_type ) {
		$meta_keys_string = array(
			'lyrico_artist',
		);

		$meta_keys_integer = array(
			'lyrico_released_year',
		);

		foreach ( $meta_keys_string as $meta_key ) :
			if ( isset( $_POST[ $meta_key ] ) ) {
				update_post_meta( $post_id, $meta_key, sanitize_text_field( wp_unslash( $_POST[ $meta_key ] ) ) );
			}
		endforeach;

		foreach ( $meta_keys_integer as $meta_key ) :
			if ( isset( $_POST[ $meta_key ] ) ) {
				update_post_meta( $post_id, $meta_key, intval( wp_unslash( $_POST[ $meta_key ] ) ) );
			}
		endforeach;
	}

}

add_action( 'save_post', 'lyrico_save_postdata' );
