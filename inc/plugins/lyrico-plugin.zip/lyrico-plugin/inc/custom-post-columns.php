<?php
/**
 * Custom Post type Columns
 *
 * @package lyrico-plugin
 * @since 1.0.0
 */

add_filter( 'manage_edit-lyrico_lyrics_columns', 'lyrics_artist_column' );
add_filter( 'manage_edit-lyrico_album_columns', 'lyrics_artist_column' );

/**
 * Custom columns for Artist post type
 *
 * @param object $columns columns.
 */
function lyrics_artist_column( $columns ) {
	$columns['artist'] = __( 'Artist', 'lyrico-plugin' );
	return $columns;
}

/**
 * Custom columns for Album post type
 *
 * @param object $columns columns.
 */
function lyrics_album_column( $columns ) {
	$columns['album'] = __( 'Album', 'lyrico-plugin' );
	return $columns;
}
add_filter( 'manage_edit-lyrico_lyrics_columns', 'lyrics_album_column' );

/**
 * Custom columns for Lyrics post type
 *
 * @param object $column_name column name.
 * @param object $post_id post id.
 */
function lyrics_column_content( $column_name, $post_id ) {
	if ( 'artist' === $column_name ) {
		if ( empty( get_post_meta( $post_id, 'lyrico_artist', true ) ) ) {
			echo '&mdash;';
		} else {
			lyrico_get_artists();
		}
	} elseif ( 'album' === $column_name ) {
		if ( empty( get_post_meta( $post_id, 'lyrico_album', true ) ) ) {
			echo '&mdash;';
			return;
		} else {
			$album = get_post_meta( $post_id, 'lyrico_album', true );
			echo esc_html( get_the_title( $album ) );
		}
	} else {
		return;
	}

}
add_action( 'manage_lyrico_lyrics_posts_custom_column', 'lyrics_column_content', 10, 2 );
add_action( 'manage_lyrico_album_posts_custom_column', 'lyrics_column_content', 10, 2 );
