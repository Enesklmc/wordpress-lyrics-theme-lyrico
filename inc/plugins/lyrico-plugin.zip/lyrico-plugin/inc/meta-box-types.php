<?php
/**
 * Meta box types
 *
 * @package lyrico-plugin
 * @since 1.0.0
 */

/**
 * Add meta box
 *
 * @param array  $args {
 *     Optional. An array of Meta box arguments.
 *
 *     @type string $id          Unique input id. Default empty.
 *     @type string $title       Text for label. Default empty.
 *     @type string $desc        Description under input. Default empty.
 *     @type string $type        Input type e.g. text/textarea/select etc. Default empty.
 *     @type string $options     Options for select input. Default empty.
 *     @type string $placeholder Text for placeholder. Default empty.
 * }
 * @param object $post_id the post id.
 */
function lyrico_create_box( $args = array(), $post_id = 0 ) {

	$defaults = array(
		'id'          => '',
		'title'       => '',
		'desc'        => '',
		'type'        => '',
		'options'     => '',
		'placeholder' => '',
	);

	$args = wp_parse_args( $args, $defaults );

	$id          = $args['id'];
	$placeholder = $args['placeholder'];
	?>

		<tr style="border-bottom: 1px dotted #ddd;">
		<th style="width:170px;">
			<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $args['title'] ); ?></label>
		</th>
		<td>
	<?php

	$value = get_post_meta( $post_id, $id, true );

	switch ( $args['type'] ) {

		case 'text':
			?>
			<input placeholder="<?php echo esc_attr( $placeholder ); ?>" name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" type="text" value="<?php echo esc_attr( $value ); ?>" style="width: 95%;" />
			<input type="hidden" name="noncename_<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>_noncename" value="<?php echo esc_attr( wp_create_nonce( plugin_basename( __FILE__ ) ) ); ?>" />
			<?php
			break;

		case 'number':
			?>
			<input name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" type="number" value="<?php echo esc_attr( $value ); ?>" style="width: 35%;" />
			<input type="hidden" name="<?php echo esc_attr( $id ); ?>_noncename" id="<?php echo esc_attr( $id ); ?>_noncename" value="<?php echo esc_attr( wp_create_nonce( plugin_basename( __FILE__ ) ) ); ?>" />
			<?php
			break;

		case 'date':
			?>
			<input name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" type="date" value="<?php echo esc_attr( $value ); ?>" style="width: 35%;" />
			<input type="hidden" name="<?php echo esc_attr( $id ); ?>_noncename" id="<?php echo esc_attr( $id ); ?>_noncename" value="<?php echo esc_attr( wp_create_nonce( plugin_basename( __FILE__ ) ) ); ?>" />
			<?php
			break;

		case 'halftext':
			?>
			<input placeholder="<?php echo esc_attr( $placeholder ); ?>" name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" type="text" value="<?php echo esc_attr( $value ); ?>" style="width: 45%;" />
			<input type="hidden" name="<?php echo esc_attr( $id ); ?>_noncename" id="<?php echo esc_attr( $id ); ?>_noncename" value="<?php echo esc_attr( wp_create_nonce( plugin_basename( __FILE__ ) ) ); ?>" />
			<?php
			break;

		case 'primary_artist_select':
			?>
			<select name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" class="lyrico-primary-artist-select" style="width:95%;">
				<option disabled selected value=""></option>
				<?php foreach ( $args['options'] as $key => $option ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>"
						<?php
						if ( $value == $key ) {
							echo ' selected="selected"';
						}
						?>
					><?php echo esc_html( $option ); ?></option>
				<?php endforeach; ?>
			</select>
			<input type="hidden" name="<?php echo esc_attr( $id ); ?>_noncename" id="<?php echo esc_attr( $id ); ?>_noncename" value="<?php echo esc_attr( wp_create_nonce( plugin_basename( __FILE__ ) ) ); ?>" />
			<?php
			break;
		case 'other_artists_select':
			$appended_artists = get_post_meta( $post_id, 'lyrico_other_artists', true );
			?>
			<select name="lyrico_other_artists[]" multiple="multiple" id="<?php echo esc_attr( $id ); ?>" class="lyrico-other-artists-select" style="width:95%;">
				<?php
				if ( $appended_artists ) {
					foreach ( $appended_artists as $artist_id ) {
						$title = get_the_title( $artist_id );
						// if the post title is too long, truncate it and add "..." at the end.
						$title = ( mb_strlen( $title ) > 50 ) ? mb_substr( $title, 0, 49 ) . '...' : $title;
						?>
						<option value="<?php echo esc_attr( $artist_id ); ?>" selected="selected"><?php echo esc_html( $title ); ?></option>
						<?php
					}
				}
				?>
			</select>
			<input type="hidden" name="lyrico_other_artists_noncename[]" id="<?php echo esc_attr( $id ); ?>_noncename" value="<?php echo esc_attr( wp_create_nonce( plugin_basename( __FILE__ ) ) ); ?>" />
			<?php
			break;
		case 'dynamic_multiple_select':
			?>
			<select name="<?php echo esc_attr( $id ); ?>[]" multiple="multiple" id="<?php echo esc_attr( $id ); ?>" class="lyrico-dynamic-multiple-select" style="width:95%;">
				<?php
				if ( $value ) {
					foreach ( $value as $value_x ) {
						?>
						<option value="<?php echo esc_attr( $value_x ); ?>" selected="selected"><?php echo esc_html( $value_x ); ?></option>
						<?php
					}
				}
				?>
			</select>
			<input type="hidden" name="lyrico_other_artists_noncename[]" id="<?php echo esc_attr( $id ); ?>_noncename" value="<?php echo esc_attr( wp_create_nonce( plugin_basename( __FILE__ ) ) ); ?>" />
			<?php
			break;
		case 'album_select':
			?>
			<select name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" class="lyrico-album-select" style="width:95%;">
				<option disabled selected value=""></option>
				<?php foreach ( $args['options'] as $key => $option ) : ?>
				<option value="<?php echo esc_attr( $key ); ?>"
					<?php
					if ( $value == $key ) {
						echo ' selected="selected"';
					}
					$artist_name = '';
					if ( ! empty( get_post_meta( $key, 'lyrico_artist', true ) ) ) {
						$artist_name = ' (' . get_the_title( get_post_meta( $key, 'lyrico_artist', true ) ) . ')';
					}
					?>
				><?php echo esc_html( $option ) . esc_html( $artist_name ); ?></option>
				<?php endforeach ?>
			</select>
			<input type="hidden" name="<?php echo esc_attr( $id ); ?>_noncename" id="<?php echo esc_attr( $id ); ?>_noncename" value="<?php echo esc_attr( wp_create_nonce( plugin_basename( __FILE__ ) ) ); ?>" />
			<?php
			break;
		case 'select':
			?>
			<select name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" class="lyrico-select-general" style="width:95%;">
				<option disabled selected value=""></option>
				<?php foreach ( $args['options'] as $key => $option ) { ?>
				<option value="<?php echo esc_attr( $key ); ?>"
					<?php
					if ( $value == $key ) {
						echo ' selected="selected"'; }
					?>
				><?php echo esc_html( $option ); ?></option>
				<?php } ?>
			</select>
			<input type="hidden" name="<?php echo esc_attr( $id ); ?>_noncename" id="<?php echo esc_attr( $id ); ?>_noncename" value="<?php echo esc_attr( wp_create_nonce( plugin_basename( __FILE__ ) ) ); ?>" />
			<?php
			break;
		case 'textarea':
			?>
			<textarea style="direction:ltr; text-align:left; width:65%;" name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" type="textarea" cols="100%" rows="4"><?php echo esc_html( $value ); ?></textarea>
			<input type="hidden" name="<?php echo esc_attr( $id ); ?>_noncename" id="<?php echo esc_attr( $id ); ?>_noncename" value="<?php echo esc_attr( wp_create_nonce( plugin_basename( __FILE__ ) ) ); ?>" />
			<?php
			break;
	}
	?>
		<?php if ( ! empty( $args['desc'] ) ) : ?>
		<div class="meta-box-description"><?php echo esc_html( $args['desc'] ); ?></div>
		<?php endif; ?>
	</td>
	</tr>
	<?php
}
