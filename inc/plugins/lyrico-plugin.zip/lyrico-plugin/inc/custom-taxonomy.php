<?php
/**
 * Create a new taxonomy: Genres
 *
 * @package lyrico-plugin
 * @since 1.0.0
 */

$labels = array(
	'name'              => _x( 'Genres', 'taxonomy general name', 'lyrico-plugin' ),
	'singular_name'     => _x( 'Genre', 'taxonomy singular name', 'lyrico-plugin' ),
	'search_items'      => esc_html__( 'Search Genres', 'lyrico-plugin' ),
	'all_items'         => esc_html__( 'All Genres', 'lyrico-plugin' ),
	'parent_item'       => esc_html__( 'Parent Genre', 'lyrico-plugin' ),
	'parent_item_colon' => esc_html__( 'Parent Genre:', 'lyrico-plugin' ),
	'edit_item'         => esc_html__( 'Edit Genre', 'lyrico-plugin' ),
	'update_item'       => esc_html__( 'Update Genre', 'lyrico-plugin' ),
	'add_new_item'      => esc_html__( 'Add New Genre', 'lyrico-plugin' ),
	'new_item_name'     => esc_html__( 'New Genre Name', 'lyrico-plugin' ),
	'menu_name'         => esc_html__( 'Genres', 'lyrico-plugin' ),
);
register_taxonomy(
	'lyrico_genres',
	array( 'lyrico_lyrics', 'lyrico_album', 'lyrico_artist', 'lyrico_playlist' ),
	array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'genre' ),
		'show_in_rest'      => true,
	)
);
