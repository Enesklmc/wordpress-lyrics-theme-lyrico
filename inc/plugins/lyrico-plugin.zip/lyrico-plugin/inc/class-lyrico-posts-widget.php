<?php
/**
 * Custom widget for lyrico
 *
 * @package lyrico-plugin
 * @since 1.0.0
 */

/**
 * This class creates custom widget that output posts
 *
 * @since 1.0.0
 */
class Lyrico_Posts_Widget extends WP_Widget {

	/**
	 * Constructor methods.
	 */
	public function __construct() {
		$widget_ops = array(
			'classname'   => 'lyrico-posts-widget',
			'description' => 'Most recent or popular: Posts, Lyrics, Artists, Albums, Playlists',
		);
		parent::__construct( 'lyrico_posts_widget', '*Lyrico Posts', $widget_ops );
	}

	/**
	 * Creating widget front-end
	 *
	 * @param object $args args.
	 * @param object $instance instance.
	 */
	public function widget( $args, $instance ) {
		$tot         = absint( empty( $instance['tot'] ) ? 8 : $instance['tot'] );
		$post_type   = empty( $instance['post_type'] ) ? 'lyrico_lyrics' : $instance['post_type'];
		$order_posts = empty( $instance['order_posts'] ) ? 'recent' : $instance['order_posts'];
		$style       = empty( $instance['post_style'] ) ? 'box_image' : $instance['post_style'];
		$style_class = 'lyrico-widget-style-' . str_replace( '_', '-', $style );
		$genre_id    = empty( $instance['genre_id'] ) ? '' : $instance['genre_id'];
		if ( ! empty( $genre_id ) ) {
			if ( 'recent' === $order_posts ) {
				$posts_query = new WP_Query(
					array(
						'post_type'           => $post_type,
						'posts_per_page'      => $tot,
						'post_status'         => 'publish',
						'orderby'             => 'post_date',
						'ignore_sticky_posts' => 1,
						'order'               => 'DESC',
						'tax_query'           => array(
							array(
								'taxonomy' => 'lyrico_genres',
								'terms'    => $genre_id,
							),
						),
					)
				);
			}
			if ( 'popular' === $order_posts ) {
				$posts_query = new WP_Query(
					array(
						'post_type'           => $post_type,
						'posts_per_page'      => $tot,
						'post_status'         => 'publish',
						'meta_key'            => 'lyrico_post_views',
						'orderby'             => 'meta_value_num',
						'order'               => 'DESC',
						'ignore_sticky_posts' => 1,
						'tax_query'           => array(
							array(
								'taxonomy' => 'lyrico_genres',
								'terms'    => $genre_id,
							),
						),
					)
				);
			}
		} else {
			if ( 'recent' === $order_posts ) {
				$posts_query = new WP_Query(
					array(
						'post_type'           => $post_type,
						'post_status'         => 'publish',
						'posts_per_page'      => $tot,
						'orderby'             => 'post_date',
						'order'               => 'DESC',
						'ignore_sticky_posts' => 1,
					)
				);
			}
			if ( 'popular' === $order_posts ) {
				$posts_query = new WP_Query(
					array(
						'post_type'           => $post_type,
						'posts_per_page'      => $tot,
						'post_status'         => 'publish',
						'meta_key'            => 'lyrico_post_views',
						'orderby'             => 'meta_value_num',
						'order'               => 'DESC',
						'ignore_sticky_posts' => 1,
					)
				);
			}
		}
		wp_reset_postdata();
		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		if ( ! empty( $instance['text'] ) ) {
			echo '<div class="textwidget">';

			echo esc_html( $instance['text'] );

			echo '</div>';
		}

		if ( 'card' === $style || 'square_image' === $style ) {
			echo '<div class="row no-gutters widget-content-' . esc_attr( $post_type ) . ' ' . esc_attr( $style_class ) . '">';
		} else {
			echo '<ul class="list-unstyled no-border-last-child mb-0 widget-content-' . esc_attr( $post_type ) . ' ' . esc_attr( $style_class ) . '">';
		}
		if ( $posts_query->have_posts() ) :

			// For ordered media.
			$order = 1;

			while ( $posts_query->have_posts() ) :
				$posts_query->the_post();
				$the_name = get_the_title();
				$the_link = get_permalink();
				$this_id  = get_the_ID();
				$artist   = get_post_meta( $this_id, 'lyrico_artist', true );

				switch ( $style ) :
					case 'box_image':
						?>
						<li class="mt-2">
							<?php get_template_part( 'template-parts/components/media', 'thumbnail-text' ); ?>
						</li>
						<?php
						break;
					case 'box_only_text':
						?>
						<li class="mt-2">
							<?php get_template_part( 'template-parts/components/media', 'only-text' ); ?>
						</li>
						<?php
						break;
					case 'box_number':
						?>
					<li class="mt-2">
						<?php set_query_var( 'media_order', $order ); ?>
						<?php get_template_part( 'template-parts/components/media', 'ordered' ); ?>
						<?php $order++; ?>
					</li>
						<?php
						break;
					case 'card':
						?>
					<div class="col-6 col-sm-4 col-md-12 col-lg-6 p-0">
						<?php get_template_part( 'template-parts/components/card', 'image-overlay' ); ?>
					</div>
						<?php
						break;
					case 'simple_list' || 'simple_list_ordered':
						?>
					<li>
						<?php get_template_part( 'template-parts/components/list-item', 'simple' ); ?>
					</li>
						<?php
						break;
				endswitch;
				?>
				<?php
		endwhile;

		endif;
		wp_reset_postdata();

		if ( 'card' === $style || 'square_image' === $style ) {
			echo '</div>';
		} else {
			echo '</ul>';
		}

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

	}

	/**
	 * Widget Backend
	 *
	 * @param object $instance instance.
	 */
	public function form( $instance ) {

		$post_type   = isset( $instance['post_type'] ) ? $instance['post_type'] : 'lyrico_lyrics';
		$order_posts = isset( $instance['order_posts'] ) ? $instance['order_posts'] : 'recent';
		$post_style  = isset( $instance['post_style'] ) ? $instance['post_style'] : 'box_image';
		$title       = ( ! empty( $instance['title'] ) ? $instance['title'] : 'Latest Lyrics' );
		$tot         = ( ! empty( $instance['tot'] ) ? absint( $instance['tot'] ) : 8 );
		$genre_id    = isset( $instance['genre_id'] ) ? $instance['genre_id'] : '';

		$output  = '<p>';
		$output .= '<label for="' . esc_attr( $this->get_field_id( 'title' ) ) . '">Title:</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr( $this->get_field_id( 'title' ) ) . '" name="' . esc_attr( $this->get_field_name( 'title' ) ) . '" value="' . esc_attr( $title ) . '">';
		$output .= '</p>';

		$output .= '<p>';
		$output .= '<label for="' . esc_attr( $this->get_field_id( 'tot' ) ) . '">Number Of Posts: </label>';
		$output .= '<input type="number" class="tiny-text" id="' . esc_attr( $this->get_field_id( 'tot' ) ) . '" name="' . esc_attr( $this->get_field_name( 'tot' ) ) . '" value="' . esc_attr( $tot ) . '">';
		$output .= '</p>';

		echo $output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'post_type' ) ); ?>">Post Type:</label>
			<select class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'post_type' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'post_type' ) ); ?>">
				<option value="post" <?php selected( $post_type, 'post' ); ?>>Blog Post</option>
				<option value="lyrico_lyrics" <?php selected( $post_type, 'lyrico_lyrics' ); ?>>Lyrics</option>
				<option value="lyrico_album" <?php selected( $post_type, 'lyrico_album' ); ?>>Album</option>
				<option value="lyrico_artist" <?php selected( $post_type, 'lyrico_artist' ); ?>>Artist</option>
				<option value="lyrico_playlist" <?php selected( $post_type, 'lyrico_playlist' ); ?>>Playlist</option>
			</select>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'order_posts' ) ); ?>">Show posts by: </label><br/>

				<label> <input id="recent" type="radio" name="<?php echo esc_attr( $this->get_field_name( 'order_posts' ) ); ?>" value="recent" <?php echo ( 'recent' === $order_posts ? ' checked="checked"' : '' ); ?>> Newest</label><br>

				<label><input id="popular" type="radio" name="<?php echo esc_attr( $this->get_field_name( 'order_posts' ) ); ?>" value="popular" <?php echo ( 'popular' === $order_posts ? ' checked="checked"' : '' ); ?>> Popularity</label>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'post_style' ) ); ?>">Style:</label>
			<select class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'post_style' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'post_style' ) ); ?>">
				<option value="box_image" <?php selected( $post_style, 'box_image' ); ?>>Box with image</option>
				<option value="box_number" <?php selected( $post_style, 'box_number' ); ?>>Box with ordering</option>
				<option value="box_only_text" <?php selected( $post_style, 'box_only_text' ); ?>>Box with Only Text</option>
				<option value="card" <?php selected( $post_style, 'card' ); ?>>Card</option>
				<option value="simple_list" <?php selected( $post_style, 'simple_list' ); ?>>Simple List</option>
				<option value="simple_list_ordered" <?php selected( $post_style, 'simple_list_ordered' ); ?>>Simple List (Ordered)</option>
			</select>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'genre_id' ) ); ?>">Select Genre:</label>
			<?php
			$args = array(
				'hierarchical'    => 1,
				'show_option_all' => __( 'All', 'lyrico-plugin' ),
				'taxonomy'        => 'lyrico_genres',
				'name'            => $this->get_field_name( 'genre_id' ),
				'id'              => $this->get_field_id( 'genre_id' ),
				'selected'        => $genre_id,
				'class'           => 'widefat',
			);
			wp_dropdown_categories( $args );
			?>
		</p>
		<?php
	}

	/**
	 * Updating widget replacing old instances with new
	 *
	 * @param object $new_instance new instance.
	 * @param object $old_instance old instance.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                = array();
		$instance['title']       = ( ! empty( $new_instance['title'] ) ? wp_strip_all_tags( $new_instance['title'] ) : 'Latest Lyrics' );
		$instance['tot']         = ( ! empty( $new_instance['tot'] ) ? wp_strip_all_tags( $new_instance['tot'] ) : 8 );
		$instance['post_type']   = ( ! empty( $new_instance['post_type'] ) ? wp_strip_all_tags( $new_instance['post_type'] ) : 'lyrico_lyrics' );
		$instance['order_posts'] = ( ! empty( $new_instance['order_posts'] ) ? wp_strip_all_tags( $new_instance['order_posts'] ) : 'recent' );
		$instance['post_style']  = ( ! empty( $new_instance['post_style'] ) ? wp_strip_all_tags( $new_instance['post_style'] ) : 'box_image' );
		$instance['genre_id']    = ( ! empty( $new_instance['genre_id'] ) ? wp_strip_all_tags( $new_instance['genre_id'] ) : '' );
		return $instance;
	}

}

add_action(
	'widgets_init',
	function() {
		register_widget( 'Lyrico_Posts_Widget' );
	}
);
