<?php
/**
 * Add new text format Tranlated Verse
 *
 * @package lyrico-plugin
 * @since 1.0.0
 */

/**
 * Custom Format
 */
function lyrico_custom_format_script_register() {

	// Register block editor script for backend.
	wp_register_script(
		'lyrico-custom-format-block-js', // Handle.
		plugins_url( 'translated-verse-format/dist/lyrico-custom-format.js', dirname( __FILE__ ) ), // Block.build.js: We register the block here. Built with Webpack.
		array( 'wp-rich-text' ), // Dependencies, defined above.
		filemtime( plugin_dir_path( __DIR__ ) . 'translated-verse-format/dist/lyrico-custom-format.js' ), // Version: filemtime — Gets file modification time.
		true // Enqueue the script in the footer.
	);

	// Register block editor styles for backend.
	wp_register_style(
		'lyrico-custom-format-block-editor-css', // Handle.
		plugins_url( 'translated-verse-format/dist/blocks.editor.css', dirname( __FILE__ ) ), // Block editor CSS.
		array( 'wp-edit-blocks' ), // Dependency to include the CSS after it.
		filemtime( plugin_dir_path( __DIR__ ) . 'translated-verse-format/dist/blocks.editor.css' ) // Version: File modification time.
	);

}
add_action( 'init', 'lyrico_custom_format_script_register' );

/**
 * Gutenberg Block
 */
function lyrico_custom_format_enqueue_assets_editor() {
	wp_enqueue_script( 'lyrico-custom-format-block-js' );
	wp_enqueue_style( 'lyrico-custom-format-block-editor-css' );
}
add_action( 'enqueue_block_editor_assets', 'lyrico_custom_format_enqueue_assets_editor' );

