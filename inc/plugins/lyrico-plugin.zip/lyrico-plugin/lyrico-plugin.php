<?php
/**
 * Lyrico plugin
 *
 * @package lyrico-plugin
 *
 * Plugin Name:  Lyrico Plugin
 * Description:  Created for Lyrico Theme.
 * Version:      1.0.0
 * Author:       klmcThemes
 * Author URI:   http://www.klmcthemes.com/
 * License:      GPL2 or later
 * License URI:  https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:  lyrico-plugin
 * Domain Path:  /languages
 */

defined( 'ABSPATH' ) || die( 'Access Denied.' );

class LyricoPlugin {

	function __construct() {
		add_action( 'init', array( $this, 'lyrico_custom_post_type' ) );
		add_action( 'init', array( $this, 'lyrico_custom_taxonomy' ) );
		add_action( 'init', array( $this, 'lyrico_custom_meta_boxes' ) );
	}

	function activate() {
		// generated a CPT.
		$this->lyrico_custom_post_type();
		// generated a Custom Taxonomy.
		$this->lyrico_custom_taxonomy();
		// flush rewrite rules.
		flush_rewrite_rules();
	}

	function deactivate() {
		// flush rewrite rules.
		flush_rewrite_rules();
	}

	function lyrico_custom_post_type() {
		require dirname( __FILE__ ) . '/inc/custom-post-types.php';
		require dirname( __FILE__ ) . '/inc/custom-post-columns.php';
	}

	function lyrico_custom_taxonomy() {
		require dirname( __FILE__ ) . '/inc/custom-taxonomy.php';
	}

	function lyrico_custom_meta_boxes() {
		require dirname( __FILE__ ) . '/inc/meta-box-types.php';
		require dirname( __FILE__ ) . '/inc/register-meta-boxes.php';
	}
}

if ( class_exists( 'LyricoPlugin' ) ) {
	$lyrico_plugin = new LyricoPlugin();
	require dirname( __FILE__ ) . '/inc/class-lyrico-posts-widget.php';
	require_once plugin_dir_path( __FILE__ ) . 'gutenberg-blocks/playlist-item/init.php';
	require_once plugin_dir_path( __FILE__ ) . 'gutenberg-blocks/translated-verse-format/init.php';
}

// activation.
register_activation_hook( __FILE__, array( $lyrico_plugin, 'activate' ) );

// deactivation.
register_deactivation_hook( __FILE__, array( $lyrico_plugin, 'deactivate' ) );
